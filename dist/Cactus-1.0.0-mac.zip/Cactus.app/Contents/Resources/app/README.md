# Final Year Project 2019
## B.Sc. IT (Hons.) in Computing & Business
### Daniel Vella

1. Download and install node
2. `cd` into repository
3. Run `npm install`
4. Run `npm install -g gulp`
5. Run `npm rebuild node-sass`
6. Run `npm rebuild electron`

To build the executable file for your chosen platform, run the following command:
`npm run dist`

The executable program will be found in a 'dist' folder in the local repository.