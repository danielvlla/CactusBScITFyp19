exports.dwellTime = 1500
exports.sidebarMaxLinks = 6
exports.sidebarLengthUrl = 30
exports.sidebarLengthTitle = 60
exports.rangeWidth = 300
exports.rangeHeight = 150